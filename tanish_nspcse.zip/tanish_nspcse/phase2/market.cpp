#include "market.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "map.cpp"
#include <typeinfo>
using namespace std;
CustomUnorderedMap<string,combo> book;
CustomUnorderedMap<string,int> companybook;  // buy sold net    comdata k vector me h
int total_trades=0;
int total_money=0;
int total_shares=0;
void print(string&sname,combo*&c,combo*&curr,int t){
    total_trades+=1;
    total_shares+=t;
    total_money+=t*curr->price;
    if(c->tradeType=="BUY"){
        vector<int> &x=companybook[c->companyName]->comdata;
        if(x.size()==3){
            x[0]+= t;
            x[2]-= t*curr->price;
        }
        else{
            x.push_back(t);
            x.push_back(0);
            x.push_back(-t*curr->price);
        }   
        
        vector<int> &X=companybook[curr->companyName]->comdata;
        if(X.size()==3){
            X[1]+= t;
            X[2]+= t*curr->price;
        }
        else{
            X.push_back(0);
            X.push_back(t);
            X.push_back(t*curr->price);
        }
        cout<<c->companyName<<" purchased "<<t<<" share of ";
        istringstream iss(sname);
        string temp,n;int wc=0;
        while(iss>>temp) {
            wc++;
            if(wc==1) n=temp;
            if(wc==3) break;
        }
        if(wc==2) cout<<n;
        else cout<<sname;
        cout<<" from "<<curr->companyName<<" for $"<<curr->price<<"/share"<<endl;
        return;
    }
    else{
        vector<int> &x=companybook[curr->companyName]->comdata;
        if(x.size()==3){
            x[0]+= t;
            x[2]-= t*curr->price;
        }
        else if(x.size()==0){
            x.push_back(t);
            x.push_back(0);
            x.push_back(-t*curr->price);
        }   
        
        vector<int> &X=companybook[c->companyName]->comdata;
        if(X.size()==3){
            X[1]+= t;
            X[2]+= t*curr->price;
        }
        else if(X.size()==0){
            X.push_back(0);
            X.push_back(t);
            X.push_back(t*curr->price);
        }
        cout<<curr->companyName<<" purchased "<<t<<" share of ";
        istringstream iss(sname);
        string temp,n;int wc=0;
        while(iss>>temp) {
            wc++;
            if(wc==1) n=temp;
            if(wc==3) break;
        }
        if(wc==2) cout<<n;
        else cout<<sname;
        cout<<" from "<<c->companyName<<" for $"<<curr->price<<"/share"<<endl;
        return;
    }
}

market::market(int argc, char** argv){ 
	
}
int partition(std::vector<std::pair<std::string, int>>& pairs, int low, int high) {
    std::string pivot = pairs[high].first;
    int i = low - 1;

    for (int j = low; j <= high - 1; ++j) {
        if (pairs[j].first < pivot) {
            ++i;
            std::swap(pairs[i], pairs[j]);
        }
    }

    std::swap(pairs[i + 1], pairs[high]);
    return i + 1;
}

// Quicksort function
void quickSort(std::vector<std::pair<std::string, int>>& pairs, int low, int high) {
    if (low < high) {
        int pi = partition(pairs, low, high);

        quickSort(pairs, low, pi - 1);
        quickSort(pairs, pi + 1, high);
    }
}
bool exec(string& sname,combo* &c){
    auto found=book[sname];
    if(c->tradeType=="SELL"){
        auto curr=found->Buyorders.head;
        while(found->Buyorders.size!=0){
            if(curr->expiry==-1){

            }
            else if(curr->expiry==0 || c->timestamp > curr->timestamp + curr->expiry){
                auto temp=curr->next;
                found->Buyorders.delOrder(curr);
                curr=temp;
                continue;
            }

            if(c->price <= curr->price){
                auto t=min(c->qty,curr->qty);
                curr->qty -= t;
                c->qty -= t;
                print(sname,c,curr,t);
                auto temp=curr->next;
                if(curr->qty==0){
                    found->Buyorders.delOrder(curr);
                }
                curr=temp;
                if(c->qty==0){
                    return 1;
                }
            }
            else return 0;
        }
    }
    else{
        auto curr=found->Sellorders.head;
        while(found->Sellorders.size!=0){
            if(curr->expiry==-1){
                ;
            }
            else if(curr->expiry==0 || c->timestamp > curr->timestamp + curr->expiry){
                auto temp=curr->next;
                found->Sellorders.delOrder(curr);
                curr=temp;
                continue;
            }
            if(c->price >= curr->price){
                auto t=min(c->qty,curr->qty);
                curr->qty -= t;
                c->qty -= t;
                print(sname,c,curr,t);
                auto temp=curr->next;
                if(curr->qty==0){
                    found->Sellorders.delOrder(curr);
                }
                curr=temp;
                if(c->qty==0){
                    return 1;
                }
            }
            else return 0;
        }
    }
    return 0;
}
void parseString(string& input) {
    istringstream iss(input);
    int endTime,price,q,ts;
    string sname,action,com,P1,Q1,token;
    iss >> ts >> com >> action;
    vector<pair<string,int>> v;
    while (iss >> token) {
        if (token[0] == '$') {
            P1=token;
            break;
        } else {
            pair<string,int> temp;
            temp.first= token;
            if (iss >> temp.second) {
                v.push_back(temp);
            } else {
                temp.second = 1;
                v.push_back(temp);
                iss.clear();
            }
        }
    }
    iss >> Q1 >> endTime;
    if(!P1.empty()) price = std::stoi(P1.substr(1));
    if(!Q1.empty()) q = std::stoi(Q1.substr(1));
    
    quickSort(v,0,v.size()-1);
    
    for (auto& p : v) {
        sname += p.first + " " + std::to_string(p.second) + " ";
    }
    if (!sname.empty()) {
        sname.pop_back();
    }
    combo* c=new combo(ts,com,action,price,q,endTime);
    
    if(action=="BUY"){
        if(!exec(sname,c))
            book[sname]->Buyorders.insertbuyorder(c);
    }
    else if(action=="SELL"){
        if(!exec(sname,c))
            book[sname]->Sellorders.insertsellorder(c);
    }
    else{
        cout<<"INVALID"<<endl;
    }
}
void market::start()
{
	ifstream inputFile("./samples/output.txt");
    if (!inputFile.is_open()) {
        cerr << "Error opening the file.\n";
        return;
    }
    string line;
    bool parsingEnabled = false;

    while (getline(inputFile, line) && line != "!@") {
            if (line.find("TL") == 0) {
                parsingEnabled = true;
                continue;
            }

            if (parsingEnabled && line != "!@\r\n") {
                parseString(line);
            }
        }
    cout<<"\n---End of Day---"<<endl;
    cout<<"Total Amount of Money Transferred: $"<<total_money<<endl;
    cout<<"Number of Completed Trades: "<<total_trades<<endl;
    cout<<"Number of Shares Traded: "<<total_shares<<endl;
    for(int i=0;i<companybook.capacity;i++){
        auto curr=companybook.table[i].head;
        while(curr!=NULL){
            vector<int>& x=curr->comdata;
            cout<<curr->key<<" bought ";
            cout<<x[0]<<" and sold ";
            cout<<x[1]<<" for a net transfer of $";
            cout<<x[2]<<"\n";
            curr=curr->next;
        }
    }
        
    inputFile.close();
}