#include <iostream>
#include <vector>
#include <string>
using namespace std;
class node{public:
    int cost,ords,ordb;
    bool is_valid_ordb,is_valid_ords;
    node(int c){
        cost=c;
        ords=ordb=0;
        is_valid_ordb=is_valid_ords=0;
    }
};
template<typename T>
class LL1{public:
    T* head;
    T* tail;//only in map
    int size;
    LL1(){
        head=tail=NULL;
        size=0;
    }
    void insert(T* new_node){           //only for maps
        if(head==NULL){
            head=tail=new_node;
            size++;
            return;
        }
        tail->next=new_node;
        tail=new_node;
        size++;
    }
    T* find(string n){                 //only for searching in map
        T*curr=head;
        while(curr!=NULL){
            if(curr->key==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
};
template<typename K,typename V>
class KV{public:
    K key;//STOCKNAME
    V* value;
    KV<K,V>* next;
    KV(K st){
        key=st;
        next=NULL;
    }

};
template<typename K,typename V>
class CustomUMap{public:
    vector<LL1<KV<K,V>>> table;
    size_t capacity;

    // A simple hash function for string keys
    size_t hash(const K& key) const {
        std::hash<string> hasher;
        return hasher(key) % capacity;
    }
    CustomUMap(size_t initialCapacity= 4096){
        capacity=initialCapacity;
        table.resize(capacity);
        for(int i=0;i<capacity;i++){
            table[i].head = table[i].tail = NULL;
        }
    }

    // Retrieve the value associated with a key
    KV<K, V>* find(const K &key) {                           //map["ASML"] returns a pointer to KV of "ASML" stock
        size_t index = hash(key);
        auto x = table[index].find(key);                     //returns a pointer to the KV pair else NULL
        if (x == NULL) {
            return NULL;
        } else {
            return x;
        }
    }
    void insert(string stock_name,int price){           //only for maps
        auto index=hash(stock_name);
        KV<K,V>* temp= new KV<K,V> (stock_name);
        temp->value = new V(price);
        table[index].insert(temp);
    }
};
CustomUMap<string,node> orders;
void func1(string &message){
    istringstream messageStream(message);
    string line;
    // Split the message into individual lines (lines end with #)    
    
    while (getline(messageStream, line, '#')) {
            // Remove leading and trailing whitespace
        if (!line.empty() && line.find('$') == string::npos) {         
            // Process each line and make trading decisions
            istringstream iss(line);
            string stock_name;
            double price;
            char trade_type;
            iss >> stock_name >> price >> trade_type;
            
            if(stock_name.empty()) break;   // thoda pipe error resolve krna
            
            auto found=orders.find(stock_name);    
            node* node_found=NULL;                
            if(found) node_found=found->value;
            
            // Make trading decisions based on trade_type
            if (trade_type == 'b'){
                // Buy the stock if the price is lower than your estimate
                if(found==NULL){
                    cout<< stock_name << " " << price << " s" << endl;
                    orders.insert(stock_name,price);
                }
                else{
                    bool iscancel=false;
                    if(node_found->is_valid_ordb ==1 && node_found->ordb < price) node_found->is_valid_ordb=0;
                    else if(node_found->is_valid_ordb==1 && node_found->ordb >= price) iscancel=true;
                    
                    if(node_found->is_valid_ords==1 && node_found->ords==price && iscancel==false){
                        node_found->is_valid_ords=0;
                        iscancel=true;
                    }
                    
                    if(iscancel==false)
                    {
                        if(node_found->cost < price){
                            cout<< stock_name << " " << price << " s" << endl;
                            node_found->cost=price;
                        }
                        else{
                            node_found->is_valid_ordb=1;
                            node_found->ordb=price;
                            cout<<"No Trade"<<endl;
                        }
                    }
                    else cout<<"No Trade"<<endl;
                }
            } 
            else if (trade_type == 's'){
                // Sell the stock if the price is higher than your estimate
                if(found==NULL){
                    cout<< stock_name << " " << price << " b" << endl;
                    orders.insert(stock_name,price);
                }
                else{
                    bool iscancel=false;
                    if(node_found->is_valid_ords==1 && node_found->ords > price) node_found->is_valid_ords=0;
                    else if(node_found->is_valid_ords ==1 && node_found->ords <= price) iscancel=true;
                    
                    if(node_found->is_valid_ordb==1 && node_found->ordb==price && iscancel==false){
                        node_found->is_valid_ordb=0;
                        iscancel=true;
                    }

                    if(iscancel==false)
                    {
                        if(node_found->cost > price){
                            cout<< stock_name << " " << price << " b" << endl;
                            node_found->cost=price;
                        }
                        else{
                            node_found->is_valid_ords=1;
                            node_found->ords=price;
                            cout<<"No Trade"<<endl;
                        }
                    }
                    else cout<<"No Trade"<<endl;
                }
            }
            else cout << "Unknown trade type: " << trade_type << endl;
        }
    }
}