#ifndef MY_HEADER4_H
#define MY_HEADER4_H
#include<iostream>
#include<string>
#include<vector>
#include "queue_cum_part2.cpp"

using namespace std;
CUM <string,combo*> links3;
int profit3=0;
Queue pending3;
void print_order3(combo* c,Queue& pending3){
    vector<pair<string,int>> v;
    for(int i=0;i<c->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=c->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            v.push_back({curr->key,curr->value});
            cout<<curr->key<<" "<<curr->value<<" ";
            curr=curr->next;
        }
    }
    quickSort(v,0,v.size()-1);
    string sname;
    for (auto& p : v) sname += p.first + " " + std::to_string(p.second) + " ";
    if(!sname.empty()) sname.pop_back();

    if(c->tradeType=='b')
        cout<<c->price<<" "<<c->true_arbit_qty<<" s"<<endl;
    else
        cout<<c->price<<" "<<c->true_arbit_qty<<" b"<<endl;
    c->qty -= c->true_arbit_qty;
    c->true_arbit_qty=0;
    if(c->qty==0) {
        pending3.deletecombo(c);
        links3.del(sname,c);
    }
}
bool cancel3(Queue &pending3,string &sname){
    if(pending3.front==pending3.rear) return false;
    size_t index=links3.hash(sname);
    auto curr=links3.table[index];
    Node<combo*>* prev=NULL;
    combo*to_be=pending3.rear;
    while(curr!=NULL){
        if(curr->value->price==to_be->price){
            if(curr->value->tradeType==to_be->tradeType){
                to_be->qty+=curr->value->qty;

                if(curr==links3.table[index]) links3.table[index]=curr->next;
                else prev->next=curr->next;
                pending3.deletecombo(curr->value);
                delete curr;
                return false;    
            }
            else{
                
                to_be->qty-=curr->value->qty;
                if(curr==links3.table[index]) links3.table[index]=curr->next;
                else prev->next=curr->next;
                pending3.deletecombo(curr->value);
                delete curr ;

                if(to_be->qty==0) {
                    pending3.deletecombo(to_be);
                    return true;
                }
                return false;
            }
        }
        prev=curr;
        curr=curr->next;
    }
    return false;
}
bool check3(CustomUnorderedMap<string,int> &allStocks){
    for(int i=0;i<allStocks.capacity;i++){
        LL<KeyValue<string,int>> temp=allStocks.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(curr->value!=0){
                return false;
            }
            curr=curr->next;
        }
    }
    return true;
}
void helper3(Queue& pending3,CustomUnorderedMap<string,int> &allStocks,int&maxPriceSum,int &priceSum,combo* current,vector<combo*>&PriceCombo,vector<combo*>& arbitrage_orders3){
    if(current==NULL) return;
    for(int j=0;j<=current->qty;j++){
        current->arbit_qty=j;
        if(j!=0){
            for(int i=0;i<current->pairs.capacity;i++){
                LL<KeyValue<string,int>> temp=current->pairs.table[i];
                auto curr=temp.head;
                while(curr!=NULL){
                    if(current->tradeType=='b') allStocks[curr->key]+=curr->value;
                    else allStocks[curr->key]-=curr->value;
                    curr=curr->next;
                }
            }
            if(current->tradeType=='b') priceSum+=current->price;
            else priceSum-=current->price;
        }    
        if(j==1)PriceCombo.push_back(current);
        helper3(pending3,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders3);
        //checking if a arbitrage is formed//
        if(!PriceCombo.empty() && check3(allStocks)){   
            if(priceSum > maxPriceSum){
                arbitrage_orders3=PriceCombo;
                maxPriceSum=priceSum;
                for(auto x:arbitrage_orders3){
                    x->true_arbit_qty=x->arbit_qty;
                }
            }
        }
    }
            for(int i=0;i<current->pairs.capacity;i++){
                    LL<KeyValue<string,int>> temp=current->pairs.table[i];
                    auto curr=temp.head;
                    while(curr!=NULL){
                        if(current->tradeType=='s'){
                            allStocks[curr->key]+=curr->value*current->qty;
                            if(allStocks[curr->key]==0) allStocks.erase(curr->key);
                        }
                        else{
                            allStocks[curr->key]-=curr->value*current->qty;
                            if(allStocks[curr->key]==0) allStocks.erase(curr->key);
                        }
                        curr=curr->next;
                    }
                }
            if(current->tradeType=='s')
                priceSum+=current->price*current->qty;
            else
                priceSum-=current->price*current->qty;
            current->arbit_qty=0;
            if(PriceCombo.empty()==0)PriceCombo.pop_back();
    return;
}
bool arbitrage_check3(Queue& pending3, vector<combo*>& arbitrage_orders3,int& profit3) {
    if(pending3.isEmpty()) return false; 
    if(pending3.front==pending3.rear) return false;
    int maxPriceSum = 0;  // Initialize maximum sum of prices to 0.
    int priceSum=0;
    vector<combo*> PriceCombo;  // Initialize a vector to store orders with price sum.

    combo* current = pending3.front;
    CustomUnorderedMap<string,int> allStocks;
    helper3(pending3,allStocks,maxPriceSum,priceSum,pending3.front,PriceCombo,arbitrage_orders3);
    profit3+=maxPriceSum;
    return !arbitrage_orders3.empty();
}
void func3(string &message){
            istringstream messageStream(message);
            string inputLine;
            while (getline(messageStream, inputLine, '#')){
                if(inputLine.empty() || inputLine.find('$')!=string::npos){
                    cout<<profit3<<endl;
                    break;
                }
                istringstream iss(inputLine);
                string token1;
                int token2;
                int qty_order;
                int price;
                char tradeType;
                CustomUnorderedMap<string,int>temp;
                vector<pair<string,int>> v;
                while(iss>>token1) {
                    if(token1[0]=='b' || token1[0]=='s'){
                        tradeType=token1[0];
                        break;
                    }
                    iss >> token2;
                    v.push_back({token1,token2});
                }

                if(!v.empty()){
                    auto x=v.rbegin();
                    qty_order=x->second;
                    price=stoi(x->first);
                    v.pop_back();
                }
                
                quickSort(v,0,v.size()-1);

                string sname;
                for (auto& p : v) {
                    temp[p.first]=p.second;
                    sname += p.first + " " + std::to_string(p.second) + " ";
                }
                if (!sname.empty()) {
                    sname.pop_back();
                }

                if(token1.empty()) break; // pipe error resolve
               
                pending3.enqueue(temp,tradeType,price,qty_order);
                bool iscancel=cancel3(pending3,sname);

                if(!iscancel) links3.insert(sname,pending3.rear);;
                vector<combo*> arbitrage_orders3;
                
                bool d=arbitrage_check3(pending3,arbitrage_orders3,profit3);
                if(!iscancel && d){
                    for(int i=arbitrage_orders3.size()-1;i>=0;i--){
                        print_order3(arbitrage_orders3[i],pending3);
                    }
                }
                else cout<<"No Trade"<<endl;
            }
        return ;
}
#endif