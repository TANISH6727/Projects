#ifndef MY_HEADER2_H
#define MY_HEADER2_H
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "map.cpp"
#include "cancel_map.cpp"
using namespace std;
int partition(std::vector<std::pair<std::string, int>>& pairs, int low, int high) {
    std::string pivot = pairs[high].first;
    int i = low - 1;

    for (int j = low; j <= high - 1; ++j) {
        if (pairs[j].first < pivot) {
            ++i;
            std::swap(pairs[i], pairs[j]);
        }
    }

    std::swap(pairs[i + 1], pairs[high]);
    return i + 1;
}
void quickSort(std::vector<std::pair<std::string, int>>& pairs, int low, int high) {
    if (low < high) {
        int pi = partition(pairs, low, high);

        quickSort(pairs, low, pi - 1);
        quickSort(pairs, pi + 1, high);
    }
}
class combo{public:
    CustomUnorderedMap<string,int> pairs;
    char tradeType;
    int price;
    int qty;
    int arbit_qty;
    int true_arbit_qty;
    combo* next;
    combo(){next=NULL;}
    combo(CustomUnorderedMap<string,int>&m, char type, int p,int q=0,int q1=0) {
        pairs=m;
        tradeType = type;
        price = p;
        qty=q;
        arbit_qty=q1;
        next = NULL;
    }
};
class Queue{public:
    combo* front;
    combo* rear;
    int size;
    Queue() {
        front = rear = NULL;
        size=0;
    }
    bool isEmpty(){
        return front == NULL;
    }
    void enqueue(CustomUnorderedMap<string,int>&m, char type, int p,int q=0,int q1=0) {
        combo* newCombo = new combo(m, type, p,q,q1);
        if (isEmpty()) front = rear = newCombo;
        else {
            rear->next = newCombo;
            rear = newCombo;
        }
        size++;
    }
    
    void deletecombo(combo*to_be) {
        if (isEmpty()) return;
        combo* current = front;
        combo* prev = NULL;
        while (current != NULL && current!= to_be) { // Assuming stockNames[0] contains the stock name
            prev = current;
            current = current->next;
        }
        if (current == NULL) return;                         // Node not found
        if (current == front) front = current->next;
        else prev->next = current->next;
        if (current == rear) rear = prev;
        delete current;
        size--;
    }
};
CUM <string,combo*> links;
void print_order(combo* c){
    vector<pair<string,int>> v;
    for(int i=0;i<c->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=c->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            v.push_back({curr->key,curr->value});
            cout<<curr->key<<" "<<curr->value<<" ";
            curr=curr->next;
        }
    }
    quickSort(v,0,v.size()-1);
    string sname;
    for (auto& p : v) sname += p.first + " " + std::to_string(p.second) + " ";
    if(!sname.empty())sname.pop_back();

    links.del(sname,c);
    if(c->tradeType=='b')
        cout<<c->price<<" s"<<endl;
    else
        cout<<c->price<<" b"<<endl;
}
bool cancel(Queue &pending2,string &sname){

    if(pending2.front==pending2.rear) return false;
    combo*to_be=pending2.rear;
    int index=links.hash(sname);
    auto curr=links.table[index];
    Node<combo*>* prev=NULL;
    while(curr!=NULL){
            if(curr->value->tradeType==to_be->tradeType){
                if(to_be->tradeType=='s'){
                    if(curr->value->price <= to_be->price) {   
                        pending2.deletecombo(to_be);
                        return true;
                    }
                    else {
                        auto t=curr->next;
                        if(curr==links.table[index]) {
                            links.table[index]=curr->next;
                        }
                        else prev->next=curr->next;

                        pending2.deletecombo(curr->value);
                        delete curr;
                        curr=t;
                        continue;
                    }
                }
                else{
                    if(curr->value->price >= to_be->price) {
                        pending2.deletecombo(to_be);
                        return true;
                    }
                    else {
                        auto t=curr->next;
                        if(curr==links.table[index]){
                            links.table[index]=curr->next;
                        }
                        else prev->next=curr->next;
                        pending2.deletecombo(curr->value);
                        delete curr;
                        curr=t;
                        continue;
                    }
                }
            }
            if(curr->value->tradeType!=to_be->tradeType && curr->value->price==to_be->price){
                pending2.deletecombo(to_be);
                if(curr==links.table[index]){
                    links.table[index]=curr->next;
                }
                else prev->next=curr->next;
                pending2.deletecombo(curr->value);
                delete curr;
                return true;
            }
        prev=curr;
        curr=curr->next;
    }
    return false;
}
bool check(CustomUnorderedMap<string,int> &allStocks){
    for(int i=0;i<allStocks.capacity;i++){
        LL<KeyValue<string,int>> temp=allStocks.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(curr->value!=0){
                return false;
            }
            curr=curr->next;
        }
    }
    return true;
}
void helper(Queue& pending2,CustomUnorderedMap<string,int> &allStocks,int&maxPriceSum,int &priceSum,combo* current,vector<combo*>&PriceCombo,vector<combo*>& arbitrage_orders){
    if(current==NULL) return;

    for(int i=0;i<current->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=current->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(current->tradeType=='b')
                allStocks[curr->key]+=curr->value;
            else
                allStocks[curr->key]-=curr->value;
            curr=curr->next;
        }
    }
    if(current->tradeType=='b')
        priceSum+=current->price;
    else
        priceSum-=current->price;
    PriceCombo.push_back(current);
    //checking if a arbitrage is formed
    if(!PriceCombo.empty() && check(allStocks)){   
        if(priceSum > maxPriceSum){
            arbitrage_orders=PriceCombo;
            maxPriceSum=priceSum;
        }
    }
    else
        helper(pending2,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders);
    
    for(int i=0;i<current->pairs.capacity;i++){
            LL<KeyValue<string,int>> temp=current->pairs.table[i];
            auto curr=temp.head;
            while(curr!=NULL){
                if(current->tradeType=='s')
                    allStocks[curr->key]+=curr->value;
                else
                    allStocks[curr->key]-=curr->value;
                curr=curr->next;
            }
        }
    PriceCombo.pop_back();
    if(current->tradeType=='s')
        priceSum+=current->price;
    else
        priceSum-=current->price;
    helper(pending2,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders);
    return;
}
bool arbitrage_check(Queue& pending2, vector<combo*>& arbitrage_orders,int& profit) {
    if(pending2.isEmpty()) return false; 
    if(pending2.front==pending2.rear) return false;
    int maxPriceSum = 0;  // Initialize maximum sum of prices to 0.
    int priceSum=0;
    vector<combo*> PriceCombo;  // Initialize a vector to store orders with price sum.

    combo* current = pending2.front;
    CustomUnorderedMap<string,int> allStocks;
    helper(pending2,allStocks,maxPriceSum,priceSum,pending2.front,PriceCombo,arbitrage_orders);
    profit+=maxPriceSum;
    return !arbitrage_orders.empty();
}
int profit=0;
Queue pending2;
void func2(string &message){
            istringstream messageStream(message);
            string inputLine;
            while (getline(messageStream, inputLine, '#')){
                if(inputLine.empty() || inputLine.find('$')!=string::npos){
                    cout<<profit<<endl;
                    break;
                }
                
                istringstream iss(inputLine); // Create a string stream to parse the line
                string token1;
                string token2;
                int price;
                char tradeType;
                CustomUnorderedMap<string,int>temp;
                vector<pair<string,int>> v;
                // Read stock names and quantities until the price is reached
                while (iss >> token1 >> token2) {
                    if (token2[0] == 'b' || token2[0] == 's') {
                        price = stoi(token1);
                        tradeType = token2[0];
                        break;
                    }
                    int p=stoi(token2);
                    temp[token1] = p;
                    v.push_back({token1,p});
                }
                quickSort(v,0,v.size()-1);
                string sname;
                for (auto& p : v) sname += p.first + " " + std::to_string(p.second) + " ";
                if (!sname.empty()) sname.pop_back();

                if(token1.empty()) break; // pipe error resolve

                pending2.enqueue(temp,tradeType,price);
                bool iscancel=cancel(pending2,sname);
                
                if(!iscancel) links.insert(sname,pending2.rear);
                
                vector<combo*> arbitrage_orders;
                bool d=arbitrage_check(pending2,arbitrage_orders,profit);
                if(!iscancel && d){
                    for(int i=arbitrage_orders.size()-1;i>=0;i--){
                        print_order(arbitrage_orders[i]);
                        pending2.deletecombo(arbitrage_orders[i]);
                    }
                }
                else{
                    cout<<"No Trade"<<endl;
                }
            }
}
#endif // MY_HEADER_H