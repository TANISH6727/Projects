#ifndef MY_HEADER5_H
#define MY_HEADER5_H
#include<iostream>
#include<vector>
#include<string>
using namespace std;
template <typename V>
struct Node {
    V value;
    Node* next;

    Node(const V& v) : value(v), next(nullptr) {}
};

// CustomUnorderedMap class
template <typename K, typename V>
class CUM {
public:
    static const int TABLE_SIZE = 4096; // Size of the hash table

    Node<V>* table[TABLE_SIZE]; // Hash table array

    // Hash function
    size_t hash(const K& key){
        std::hash<string> hasher;
        return hasher(key) % TABLE_SIZE;
    }

public:
    // Constructor
    CUM() {
        // Initialize the hash table array
        for (int i = 0; i < TABLE_SIZE; ++i) {
            table[i] = NULL;
        }
    }

    // Insert key-value pair into the map
    void insert(const K& key, const V& value) {
        size_t index = hash(key);
        Node<V>* newNode = new Node<V>(value);

        // Insert the node at the beginning of the linked list
        newNode->next = table[index];
        table[index] = newNode;
    }

    void del(const K & key,auto c){
        size_t index=hash(key);
        auto curr=table[index];
        if(curr->value==c){
            table[index]=curr->next;
            delete curr;
            return ;
        }
        auto prev=curr;
        curr=curr->next;
        while(curr!=NULL){
            if(curr->value==c){
                prev->next=curr->next;
                delete curr;
                return;
            }
            prev=curr;
            curr=curr->next;
        }
    }
};
#endif