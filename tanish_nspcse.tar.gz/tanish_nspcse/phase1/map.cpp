#ifndef MY_HEADER3_H
#define MY_HEADER3_H
#include <iostream>
#include <vector>
#include<string>
using namespace std;
// Define a custom pair to hold key-value pairs
template <typename K, typename V>
struct KeyValue {
    K key;
    V value;
    KeyValue* next;
    KeyValue(){
        key="";
        value=0;
    }
    KeyValue(const K& k, const V& v){
        key=k; 
        value=v;
        next=NULL;
    }   
};
template<typename T>
class LL{public:
    T* head;
    T* tail;
    int size;
    LL(){
        head=tail=NULL;
        size=0;
    }
    void insert(string n,int c){
        T*new_node=new T(n,c);
        if(head==NULL){
            head=tail=new_node;
            size++;
            return;
        }
        tail->next=new_node;
        tail=new_node;
        size++;
    }
    T* find(string n){
        T*curr=head;
        while(curr!=NULL){
            if(curr->key==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
    void del(string k){
        if(head==NULL) return;
        T*curr=head;
        if(curr->key==k){
            if(head==tail){
                delete(head);
                size--;
                head=tail=NULL;
                return;
            }
            delete(head);
            size--;
            head=curr->next;
            return;
        }
        while(curr!=NULL && curr->next!=NULL){
            if(curr->next->key==k){
                T*to_be=curr->next;
                curr->next=to_be->next;
                if(to_be==tail){
                    tail=curr;
                }
                delete(to_be);
                size--;
                break;
            }
            curr=curr->next;
        }
    }
};

template <typename K, typename V>
class CustomUnorderedMap {
public:
    std::vector<LL<KeyValue<K, V>>> table;
    size_t capacity;

    // A simple hash function for string keys
    size_t hash(const K& key) {
        std::hash<string> hasher;
        return hasher(key) % capacity;
    }

    CustomUnorderedMap(size_t initialCapacity = 8){
        capacity=initialCapacity;
        table.resize(capacity);
        for(int i=0;i<capacity;i++){
            table[i].head = table[i].tail = NULL;
        }
    }

    // Insert a key-value pair into the map
    void insert(const K& key, const V& value) {
        size_t index = hash(key);
        auto x=table[index].find(key);
        if(x!=NULL){
            x->value=value;
            return;
        }
        table[index].insert(key, value);
    }

    // Retrieve the value associated with a key
    V& operator[](const K& key) {
        size_t index = hash(key);
        auto x=table[index].find(key);
        if(x==NULL){
            // If key doesn't exist, insert a new key-value pair
            insert(key, V());
            return table[index].tail->value;
        }
        else{
            return x->value;
        }
    }

    // Remove a key-value pair from the map
    void erase(const K& key) {
        size_t index = hash(key);
        table[index].del(key);
    }
};
#endif // MY_HEADER3_H