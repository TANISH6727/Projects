#ifndef MY_HEADER7_H
#define MY_HEADER7_H
#include <iostream>
#include <atomic>
#include <string>
#include <vector>
#include <mutex>
#include <thread>
#include <chrono>
#include <fstream>
#include "map.cpp"
#include "median_map.cpp"
#include <sstream>
using namespace std;
extern std::mutex printMutex;  // Declare the mutex for printing
CustomUnorderedMap <string,combo> book1;
CUMap median_book;
int linesPrinted = 0;
int linesProcessed=0;

bool exec1(string& sname,combo* &c){
    auto found=book1[sname];
    if(c->tradeType=="SELL"){
        auto curr=found->Buyorders.head;

        while(found->Buyorders.size!=0){
            if(curr->expiry==-1){         
       
            }

            else if(curr->expiry==0 || c->timestamp > curr->timestamp + curr->expiry){
                auto temp=curr->next;
                found->Buyorders.delOrder(curr);
                curr=temp;
                continue;
            }

            if(c->price <= curr->price){
                auto t=min(c->qty,curr->qty);
                curr->qty -= t;
                c->qty -= t;
                // print1(sname,c,curr,t);
                auto f=median_book.get(sname);
                if(!f){
                median_node* temp= new median_node;
                median_book.insert(sname,temp);
                }
                f=median_book.get(sname);
                for(int i=0;i<t;i++)
                    f->insert(curr->price);
                
                auto temp=curr->next;
                if(curr->qty==0){
                    found->Buyorders.delOrder(curr);
                }  
                curr=temp;
                if(c->qty==0){
                    return 1;
                }
            }
            else return 0;
        }
    }
    else{
        auto curr=found->Sellorders.head;
        while(found->Sellorders.size!=0){
            if(curr->expiry==-1){
                ;
            }
            else if(curr->expiry==0 || c->timestamp > curr->timestamp + curr->expiry){
                auto temp=curr->next;
                found->Sellorders.delOrder(curr);
                curr=temp;
                continue;
            }
            if(c->price >= curr->price){
                auto t=min(c->qty,curr->qty);
                curr->qty -= t;
                c->qty -= t;
                // print1(sname,c,curr,t);
                auto f=median_book.get(sname);
                if(!f){
                median_node* temp= new median_node;
                median_book.insert(sname,temp);
                }
                f=median_book.get(sname);
                for(int i=0;i<t;i++)
                    f->insert(curr->price);
                
                auto temp=curr->next;
                if(curr->qty==0){
                    found->Sellorders.delOrder(curr);
                }
                curr=temp;
                if(c->qty==0){
                    return 1;
                }
            }
            else return 0;
        }
    }
    return 0;
}
void parseString1(string &input){
    istringstream iss(input);
    int endTime,price,q,ts;
    string sname,action,com,P1,Q1,token;
    iss >> ts >> com >> action;
    if(com=="22b0978_22b0974") return;
    vector<pair<string,int>> v;
    while (iss >> token) {
        if (token[0] == '$') {
            P1=token;
            break;
        } else {
            pair<string,int> temp;
            temp.first= token;
            if (iss >> temp.second) {
                v.push_back(temp);
            } else {
                temp.second = 1;
                v.push_back(temp);
                iss.clear();
            }
        }
    }
    iss >> Q1 >> endTime;
    if(!P1.empty()) price = std::stoi(P1.substr(1));
    if(!Q1.empty()) q = std::stoi(Q1.substr(1));
    
    //quickSort(v,0,v.size()-1);
    
    for (auto& p : v) {
        sname += p.first + " " + std::to_string(p.second) + " ";
    }
    if (!sname.empty()) {
        sname.pop_back();
    }
    combo* c=new combo(ts,com,action,price,q,endTime);
    // 7 KarGoCorp SELL GE $50 #15 -1
    if(action=="BUY"){
        if(!exec1(sname,c)){
            auto f=median_book.get(sname);
            if(!f){
                median_node* temp= new median_node;
                median_book.insert(sname,temp);
            }
            f=median_book.get(sname);
            // f->insert(curr->price);

            if(price > f->median){
                cout<<c->timestamp<<" 22b0978_22b0974 SELL "<<sname<<" $"<<price<<" #"<<q<<" "<<endTime<<endl;
                prof+= price - f->median;
                for(int i=0;i<q;i++)
                    f->insert(price);
                // linesPrinted++;
                // linesProcessed++;
            }
            else
                book1[sname]->Buyorders.insertbuyorder(c);
        }
    }
    else if(action=="SELL"){
        if(!exec1(sname,c)){
            auto f=median_book.get(sname);
            if(!f){
            median_node* temp= new median_node;
            median_book.insert(sname,temp);
            }
            f=median_book.get(sname);
            // f->insert(curr->price);

            if(price < f->median){
                cout<<c->timestamp<<" 22b0978_22b0974 BUY "<<sname<<" $"<<price<<" #"<<q<<" "<<endTime<<endl;
                prof+= -price + f->median;
                for(int i=0;i<q;i++)
                    f->insert(price);
                // linesPrinted++;
                // linesProcessed++;
            }
            else
                book1[sname]->Sellorders.insertsellorder(c);
        }
    }
    else{
        delete c;
    }
}

int reader(int time) {
    static std::ifstream inputFile("output.txt");

    if (!inputFile.is_open()) {
        return 1;
    }

    std::string line;
    bool parsingEnabled = false;

    while (true) {
        linesProcessed = 0;
        // Check if the end of file is reached
        if (inputFile.eof()) {
            // Reset the file stream position to the beginning
            inputFile.clear(); // Clear the EOF flag
            inputFile.seekg(0, std::ios::beg);
        }

        while (std::getline(inputFile, line)) {
            if (line.empty()) {
                continue;
            }

            if (line.find("TL") != std::string::npos) {
                parsingEnabled = true;
                // linesPrinted++;
                continue;  // Skip the line with "TL"
            }

            if (line.find("!@") != std::string::npos) {
                return 1;  // Return 1 when "@!" is encountered
            }

            if (parsingEnabled) {
                if (linesProcessed < linesPrinted) {
                    // Skip printing this line
                    ++linesProcessed;
                    continue;
                }

                parseString1(line);
                ++linesProcessed;
            }
        }
        linesPrinted=linesProcessed;
    }

    // The function will never reach this point
    return 0;  // This is just to satisfy the function's return type
}

int trader(std::string *message)
{
    return 1;
}

#endif