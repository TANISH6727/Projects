#include <iostream>
#include <string>
#include<vector>
using namespace std;
// median_node definition
struct median_node {
    vector<int> med_data;
    float median;
    median_node(float m=0){
        median=m;
    }
    void insert(int p){
        int i = 0;
        while (i < med_data.size() && p > med_data[i]) {
            ++i;
        }

        // Insert the element at the found position
        med_data.insert(med_data.begin() + i, p);
        int n=med_data.size();
        if(n%2==1)
            median= med_data[n/2 ];
        else
            median= 0.5 *( med_data[n/2 ] + med_data[n/2 -1 ]);
    }
    // Add any other members as needed
};

// Custom unordered map node
struct CustomMapNode {
    std::string key;
    median_node* data;
    CustomMapNode* next;
};

// Custom unordered map implementation
class CUMap {
private:
    static const int HASH_TABLE_SIZE = 100; // Adjust the size based on your needs
    CustomMapNode* hashTable[HASH_TABLE_SIZE];

    // Custom hash function
    size_t customHash(const std::string& key) {
        std::hash<string> hasher;
        return hasher(key) % HASH_TABLE_SIZE;
    }

public:
    CUMap() {
        // Initialize the hash table
        for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
            hashTable[i] = nullptr;
        }
    }

    // Insert a key-value pair into the map
    void insert(const std::string& key, median_node* data) {
        size_t index = customHash(key);

        // Create a new node
        CustomMapNode* newNode = new CustomMapNode{key, data, nullptr};

        // Insert at the beginning of the linked list
        newNode->next = hashTable[index];
        hashTable[index] = newNode;
    }

    // Retrieve data for a given key
    median_node* get(const std::string& key) {
        size_t index = customHash(key);

        // Search for the key in the linked list
        CustomMapNode* current = hashTable[index];
        while (current != nullptr) {
            if (current->key == key) {
                return current->data;
            }
            current = current->next;
        }

        return nullptr; // Key not found
    }

    // Destructor to free memory
};
