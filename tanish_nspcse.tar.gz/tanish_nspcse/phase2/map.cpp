#include<iostream>
#include<vector>
#include<string>
using namespace std;
class combo{public:
    string companyName;
    string tradeType;
    vector<int> price_history;
    int median=0;
    int price;
    int qty;
    int timestamp;
    int expiry;
    combo* next;
    combo(int ts,string com,string tt,int p,int q,int e,int m=0){
        companyName=com;
        tradeType=tt;
        timestamp=ts;
        price=p;
        qty=q;
        expiry=e;
        median=m;
        next=NULL;
    }
};
template<typename T>
class LL{public:
    T* head;
    T* tail;//only in map
    int size;
    LL(){
        head=tail=NULL;
        size=0;
    }
    void insert(T* new_node){           //only for maps
        if(head==NULL){
            head=tail=new_node;
            size++;
            return;
        }
        tail->next=new_node;
        tail=new_node;
        size++;
    }
    void insertbuyorder(T*new_node){
        size++;
        if(head==NULL){
            head=new_node;
            return;
        }
        if(head->price < new_node->price){
            new_node->next=head;
            head=new_node;
            return;
        }
        T*prev=head;
        while(prev->next!=NULL){
            if(prev->next->price < new_node->price) break;                    
            prev=prev->next;
        }
        new_node->next=prev->next;
        prev->next=new_node;
    }
    void insertsellorder(T*new_node){
        size++;
        if(head==NULL) {
            head=new_node;
            return;
        }
        if(head->price > new_node->price){
            new_node->next=head;
            head=new_node;
            return;
        }
        T*prev=head;
        while(prev->next!=NULL){
            if(prev->next->price > new_node->price) break;                    
            prev=prev->next;
        }
        new_node->next=prev->next;
        prev->next=new_node;
    }
    T* find(string n){                 //only for searching in map
        T*curr=head;
        while(curr!=NULL){
            if(curr->key==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
    void delOrder(T*to_be){
        if(head==NULL) return;
        if(head==to_be){
            head=to_be->next;
            delete(to_be);
            size--;
            return;
        }
        T*curr=head;
        while(curr->next!=NULL && curr->next!=to_be) curr=curr->next;
        if(curr->next==NULL) return;
        else {
            curr->next=to_be->next;
            delete(to_be);
            size--;
        }
    }
    void del(string k){                //for deleting one particular stock from the map
        if(head==NULL) return;
        T*curr=head;
        if(curr->key==k){
            if(head==tail){
                delete(head);
                size--;
                head=tail=NULL;
                return;
            }
            delete(head);
            size--;
            head=curr->next;
            return;
        }
        while(curr!=NULL && curr->next!=NULL){
            if(curr->next->key==k){
                T*to_be=curr->next;
                curr->next=to_be->next;
                if(to_be==tail){
                    tail=curr;
                }
                delete(to_be);
                size--;
                break;
            }
            curr=curr->next;
        }
    }
};
template<typename K,typename V>
class KeyValue{public:
    K key;//STOCKNAME
    LL<V> Buyorders;
    LL<V> Sellorders;
    vector<V> comdata;
    KeyValue<K,V>* next;
    KeyValue(K st){
        key=st;
        Buyorders.head=Buyorders.tail=NULL;
        Sellorders.head=Sellorders.tail=NULL;
        next=NULL;
    }
};
template<typename K,typename V>
class CustomUnorderedMap{public:
    vector<LL<KeyValue<K,V>>> table;
    size_t capacity;

    // A simple hash function for string keys
    size_t hash(const K& key) const {
        std::hash<string> hasher;
        return hasher(key) % capacity;
    }


    CustomUnorderedMap(size_t initialCapacity = 64){
        capacity=initialCapacity;
        table.resize(capacity);
        for(int i=0;i<capacity;i++){
            table[i].head = table[i].tail = NULL;
        }
    }

    // Retrieve the value associated with a key
    KeyValue<K, V>* operator[](const K &key) {              //map["ASML"] returns a pointer to KeyValue of "ASML" stock
        size_t index = hash(key);
        auto x = table[index].find(key);                     //returns a pointer to the keyvalue pair else NULL
        if (x == NULL) {
            KeyValue<K, V> *newPair=new KeyValue<K,V> (key);
            table[index].insert(newPair);                    //LL ka insert call ho gya to ye jo newPair h ye table[index] ke end me gya hoga
            return table[index].tail;
        } else {
            return x;
        }
    }

    // Remove a key-value pair from the map
    void erase(const K key) {
        size_t index = hash(key);
        table[index].del(key);
    }
    void print(){
        for(int i=0;i<capacity;i++){
            LL<KeyValue<K,V>> curr=table[i];
            curr.prin();
        }
    }
};